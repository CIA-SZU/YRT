function GA = Reaction(GA,Benchmark)
global Q_reacting_table;

global DQNet1 DQNet1_target ;

% GA_X = (GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(GA.PopulationSize,GA.Dimension)));
% GA.SavePopulation = GA.SaveTransferPop;
% GA.SaveFitness = GA.SaveTransferFit;



GA.SavePopulation =GA.Population.TestPop;
GA.SaveFitness =GA.Population.TestFit;
Flag_fit = 0;
Flag_num = 0;
[F_size,~] = size(GA.SavePopulation);
for kk=1: F_size
%     ViolateNum(GA.SavePopulation(kk,:)',Benchmark)
    if ViolateNum(GA.SavePopulation(kk,:)',Benchmark)==0
        Flag_num = Flag_num + 1;
    end
%     GA.Population.X(jj,:) =  last_X(jj,:); 
end
Flag_fit = Flag_num/F_size;
Flag_fit
% TextX = [GA.Population.X,GA.Population.FitnessValue,GA.Population.ViolateValue'];
% Flag_fit=sim(DQNet1,TextX);
% Flag_fit = sum(abs(Flag_fit))/12;
% [DQNet1,~] = adapt(DQNet1,p1,t1);
Flag_fit = selectAction(DQNet1);

[SolutionNumber,~] = size(GA.Population.X);
if Flag_fit>=0.8
    state_reacting = 1;
elseif Flag_fit<=0.1
    state_reacting = 2;
else
    state_reacting = 3;
end
%�Ӵ浵��ѡ�����ʱ��Ҳ�����������ѡ����������Ӧ��
this_action = find(Q_reacting_table(state_reacting,:)==max(Q_reacting_table(state_reacting,:)));
this_action = this_action(1);
reward = 0;
if this_action == 1
    
    [this_value,SortedList]=sort(GA.SaveFitness,'descend');
    %[this_value,SortedList]=sort(GA.SaveFitness,'descend');
    %SortedList = SortedList(1:GA.NumberOfFeasiblePopulations);
    for jj=1: GA.PopulationSize-GA.NumberOfRestingPopulations
        last_X(jj,:) = GA.SavePopulation(SortedList(F_size-jj+1),:);
        %     GA.Population.X(jj,:) =  last_X(jj,:);
    end
    for pp=SolutionNumber-GA.NumberOfRestingPopulations + 1 : SolutionNumber
        last_X(pp,:) =  (GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(1,GA.Dimension)))';%
    end
elseif this_action == 2%��ǰ��Ⱥ����û���н⣬����������ų�,�����н��������Ⱥ
    ll = 1;
    for kk=1: F_size
        if ViolateNum(GA.SavePopulation(kk,:)',Benchmark)==0
            last_X(kk,:) = GA.SavePopulation(kk,:);
            ll = ll + 1;
        end
    end
    for pp = ll : SolutionNumber
        last_X(pp,:) = (GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(1,GA.Dimension)))';
    end
   
else 
    pp = 1;
    for kk = 1 : F_size
        if ViolateNum(GA.SavePopulation(kk,:)',Benchmark)==0
            last_X(pp,:) = GA.SavePopulation(kk,:);
            pp = pp + 1;
        end
        if pp>=SolutionNumber * Flag_fit
            break;
        end
    end  
    now_X = TransferReaction(GA,Benchmark,pp);
    for i = pp:SolutionNumber
        last_X(i,:) = now_X(i,:);
    end
    
end

for kk=1: SolutionNumber
    if ViolateNum(last_X(kk,:)',Benchmark)==0
        reward = reward + 1;
    else
        reward = reward - 1;
    end
end
Q_reacting_table(state_reacting,this_action) = Q_reacting_table(state_reacting,this_action) + 0.3 * (reward + 0.75 * max(Q_reacting_table(state_reacting,:))  - Q_reacting_table(state_reacting,this_action));


 GA.Population.X = last_X;
 [GA.Population.X,GA.Population.FitnessValue,GA.Population.ViolateValue] = MakeFeasible(GA,Benchmark,GA.MinCoordinate,GA.MaxCoordinate,GA.Dimension);
 GA.SaveTransferPop = NaN;


GA.Population.PbestPosition = GA.Population.X;
[GA.Population.PbestValue,~,~] = benchmark_func(GA.Population.PbestPosition , Benchmark);
[GA.Population.GbestValue,BestPbestID] = max(GA.Population.PbestValue);
GA.Population.GbestPosition = GA.Population.PbestPosition(BestPbestID,:);
trainOnBuffer(DQNet1);
end

function selectedAction = selectAction(DQNet1)            
  if rand <= DQNet1.epsilon                
      actionIndex = randi(DQNet1.actionCardinality,1);                
  else                
      DQNet1.Q = DQNet1.genQvalue(DQNet1.state);                
      [~,actionIndex] = max(DQNet1.Q);                
  end            
  selectedAction = DQNet1.actions(actionIndex);
end

function trainOnBuffer(DQNet1)            
    sampledrawfromBuffer = datasample(DQNet1.replayBuffer,min(DQNet1.sampleSize,length(DQNet1.replayBuffer)));
    stateBatch = sampledrawfromBuffer(:,[1:4]);
    actionBatch = sampledrawfromBuffer(:,5);
    rewardBatch = sampledrawfromBuffer(:,6);
    nextstateBatch = sampledrawfromBuffer(:,[7:10]);
    doneBatch = sampledrawfromBuffer(:,11);
    valueBatch = zeros(length(DQNet1.actions),1);            
    for count = 1:length(sampledrawfromBuffer)                
        value = DQNet1.genQvalue(stateBatch(count,:));
        aIdx = find(~(DQNet1.actions-actionBatch(count)));
        if doneBatch(count)
            value(aIdx) = rewardBatch(count);
        else
            value(aIdx) = rewardBatch(count) + DQNet1.gamma*max(DQNet1.genQvalue(nextstateBatch(count,:)));
        end
        valueBatch(:,count) = value;
    end            
    DQNet1.net = setwb(DQNet1.net,DQNet1.netWeights);
    DQNet1.net = train(DQNet1.net, stateBatch',valueBatch);
    DQNet1.netWeights = getwb(DQNet1.net);           
end



