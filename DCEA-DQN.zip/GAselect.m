function GA = GAselect(GA,Benchmark)
X = [GA.Population.X;GA.SaveX];
% X = unique(X,'rows','stable');
[SolutionNumber,~] = size(X);
% for ii = 1:GA.PopulationSize  
%     rand_x(1) = ii;
%     rand_x(2) = GA.PopulationSize + ii;
%     fit_x1 = FitnessNum(X(rand_x(1),:)',Benchmark);
%     vio_x1 = ViolateNum(X(rand_x(1),:)',Benchmark);
%     fit_x2 = FitnessNum(X(rand_x(2),:)',Benchmark);
%     vio_x2 = ViolateNum(X(rand_x(2),:)',Benchmark);
%     if vio_x1==vio_x2
%         if(fit_x1>fit_x2)
%             this_x(ii,:) = X(rand_x(1),:);
%             this_fitnessvalue(ii) = fit_x1;
%         else
%             this_x(ii,:) = X(rand_x(2),:);
%             this_fitnessvalue(ii) = fit_x2;
%         end
%     elseif vio_x1 < vio_x2
%         this_x(ii,:) = X(rand_x(1),:);
%         this_fitnessvalue(ii) = fit_x1;
%     else
%         this_x(ii,:) = X(rand_x(2),:);
%         this_fitnessvalue(ii) = fit_x2;
%     end
% end


NewX = NaN(GA.PopulationSize,GA.Dimension);
for kk = 1 : SolutionNumber
    this_fitnessvalue(kk) = FitnessNum(X(kk,:)',Benchmark);
    this_violatevalue(kk) = ViolateNum(X(kk,:)',Benchmark);
end
this_k = 0;
while this_k<GA.PopulationSize
    this_min_num = min(this_violatevalue);
    k_num = find(this_violatevalue==this_min_num);
    if this_k+size(k_num)<=GA.PopulationSize
        for oo = 1:size(k_num)
            this_k = this_k + 1;
            NewX(this_k,:) = X(k_num(oo),:);
            this_violatevalue(k_num(oo)) = 99999;
            this_fitnessvalue(k_num(oo)) = -99999;
        end
    else
        now_fit = this_fitnessvalue(k_num);
        [~,n_key] = sort(now_fit,'descend');
        for oo = 1:GA.PopulationSize-this_k
            this_k = this_k + 1;
            NewX(this_k,:) = X(k_num(n_key(oo)),:);
        end
    end
end
GA.Population.X = NewX;
for kk = 1:GA.PopulationSize
    GA.Population.FitnessValue(kk) = FitnessNum(GA.Population.X(kk,:)',Benchmark);
    GA.Population.ViolateValue(kk) = ViolateNum(GA.Population.X(kk,:)',Benchmark);
end
end

