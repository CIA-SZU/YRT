function init_population = TransferReaction(GA,Benchmark,pp)

% Find the latent space of domain adaptation
mu = 0.5;
lambda = 'unused';
dim = 7;           % Deduced dimension
kind = 'Gaussian';  % The dimension of Gaussian Kernel feature space is inifinite, so the deduced dimension can be 20.
% p1 = 1;
% p2 = 'unused';
% p3 = 'unused';
p1 = 1/2;
p2 = 0;
p3 = 3;

W = getW(GA.Population.X1RealVio', GA.Population.X2RealVio', mu, lambda, dim, kind, p1, p2, p3);
GA.SaveTransferPop = GA.Population.TestPop;
[SPNum,~] = size(GA.SaveTransferPop);
SPNum = randperm(SPNum);
SPNum = SPNum(1:GA.PopulationSize);
FeasiblePop = GA.SaveTransferPop(SPNum,:);
% FeasiblePop = GA.SaveTransferPop((SPNum-GA.PopulationSize+1):SPNum,:);
for ii =1:GA.PopulationSize
    ViolatePop(ii,1) = RealViolateNum(FeasiblePop(ii,:),Benchmark);
    ViolatePop(ii,2) = FitnessNum(FeasiblePop(ii,:)',Benchmark);
end
Feasible_deduced = getNewF(GA.Population.X1RealVio', GA.Population.X2RealVio', ViolatePop', W, kind, p1, p2, p3);
dis_px = @(p, x)sum((getNewF(GA.Population.X1RealVio', GA.Population.X2RealVio', this_FandV(x,Benchmark)', W, kind, p1, p2, p3) - p).^2);
% initn = size(Feasible_deduced, 2);
initn = GA.PopulationSize;
n = GA.Dimension;
init_population = zeros(initn, n);


rad_vioNum = 0;
this_vioNum = 0;
for i = pp:initn
    init_population(i,:) = fmincon(@(x)dis_px(Feasible_deduced(:,i), x),(GA.MinCoordinate + (GA.MaxCoordinate-GA.MinCoordinate).*rand(1,GA.Dimension)), ...
        [], [], [], [],GA.MinCoordinate * ones(1,n), GA.MaxCoordinate * ones(1,n), [], optimset('display', 'off'));
%     randomPop(i,:) = GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(1 ,GA.Dimension));
%     this_vioNum= ViolateNum(init_population(i,:)',Benchmark) + this_vioNum; 
%     rad_vioNum = ViolateNum(randomPop(i,:)',Benchmark) + rad_vioNum; 
end
%�õ�����Ⱥ���ƺ����б�ã����������˾ֲ����ţ�
%�ǲ����ṩ��FeasiblePop̫������һ�������ˣ�����Ϊʲô����ʽ�˺�����ô�����ȸ�˹�˺���

% GA.Population.X = init_population;
% 
% for i = 1:initn
%     this_pNum(i,:) = PeakNum(GA.Population.X(i,:)',Benchmark); 
% end
% GA.Population.PbestPosition = GA.Population.X;
% [GA.Population.PbestValue,~,~] = benchmark_func(GA.Population.PbestPosition , Benchmark);
% [GA.Population.GbestValue,BestPbestID] = max(GA.Population.PbestValue);
% GA.Population.GbestPosition = GA.Population.PbestPosition(BestPbestID,:);
end

% 
% function pNum = PeakNum(x,Benchmark)
% ldim = 1;
% pNum = -1;
% for ii=1 : Benchmark.MPBnumber
%     solution = x;
%     solution = x(Benchmark.PermutationMap(ldim:ldim+Benchmark.MPB{ii}.Dimension-1));%������
%     f=NaN(1,Benchmark.MPBnumber);
%     if ~isnan(solution)
%         for k=1 : Benchmark.MPB{ii}.PeakNumber
%             a = Transform((solution - Benchmark.MPB{ii}.PeaksPosition(k,:)')'*Benchmark.MPB{ii}.RotationMatrix(:,:,k)',Benchmark.MPB{ii}.tau(k),Benchmark.MPB{ii}.eta(k,:));
%             b = Transform(Benchmark.MPB{ii}.RotationMatrix(:,:,k) * (solution - Benchmark.MPB{ii}.PeaksPosition(k,:)'),Benchmark.MPB{ii}.tau(k),Benchmark.MPB{ii}.eta(k,:));
%             f(k) = Benchmark.MPB{ii}.PeaksHeight(k) - sqrt( a * diag(Benchmark.MPB{ii}.PeaksWidth(k,:).^2) * b);
%         end
%         [~,PeakNum] = max(f);
%         if pNum==-1
%             pNum = PeakNum;
%         else
%             pNum = [pNum,PeakNum];
%         end
%     end
%     ldim = ldim + Benchmark.MPB{ii}.Dimension;
% end
% end





