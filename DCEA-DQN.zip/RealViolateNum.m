function [ VioNum ] = RealViolateNum(x,Benchmark)
ldim = 1;
VioNum = 0;
this_num = 1;
for ii=1 : Benchmark.MPBnumber
    %     solution = x;
    solution = x(Benchmark.PermutationMap(ldim:ldim+Benchmark.MPB{ii}.Dimension-1));%������
    
    f=NaN(1,Benchmark.MPBnumber);
    if ~isnan(solution)
        for k=1 : Benchmark.MPB{ii}.PeakNumber
            if ~sum(ismember(Benchmark.MPB{ii}.FeasiblePeak,k))
                f(this_num) = sum((solution-Benchmark.MPB{ii}.PeaksPosition(k,:)).*(solution-Benchmark.MPB{ii}.PeaksPosition(k,:))) - (Benchmark.MPB{ii}.radius)^2;
                this_num = this_num + 1;
            end
        end
        [f,~] = min(f);
        f = f * Benchmark.MPB{ii}.Weight;
    end
    ldim = ldim + Benchmark.MPB{ii}.Dimension;
    VioNum = VioNum + f;
end
VioNum = -VioNum;
% if VioNum<=0
%     VioNum=1;
% else
%     VioNum=0;
% end
end