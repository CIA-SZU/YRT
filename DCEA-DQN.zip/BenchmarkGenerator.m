function Benchmark = BenchmarkGenerator(ScenarioNumber,ConstraintNumber)
Benchmark = [];
switch  ScenarioNumber
    case 1
        Benchmark.ComponentDimensions = [10];
        FullySeparableDimension = 0;
        Benchmark.ComponentDimensions = [Benchmark.ComponentDimensions,ones(1,FullySeparableDimension)];
        Benchmark.ChangeFrequency = 8000;
        Benchmark.Budget = 7999;
    case 2
        Benchmark.ComponentDimensions = [10];
        FullySeparableDimension = 0;
        Benchmark.ComponentDimensions = [Benchmark.ComponentDimensions,ones(1,FullySeparableDimension)];
        Benchmark.ChangeFrequency = 8000;
        Benchmark.Budget = 7999;
    case 3
        Benchmark.ComponentDimensions = [10];
        FullySeparableDimension = 0;
        Benchmark.ComponentDimensions = [Benchmark.ComponentDimensions,ones(1,FullySeparableDimension)];
        Benchmark.ChangeFrequency = 8000;
        Benchmark.Budget = 7999;
    case 4
        Benchmark.ComponentDimensions = [10];
        FullySeparableDimension = 0;
        Benchmark.ComponentDimensions = [Benchmark.ComponentDimensions,ones(1,FullySeparableDimension)];
        Benchmark.ChangeFrequency = 8000;
        Benchmark.Budget = 7999;
    case 5
        Benchmark.ComponentDimensions = [4,2,2];
        FullySeparableDimension = 2;
        Benchmark.ComponentDimensions = [Benchmark.ComponentDimensions,ones(1,FullySeparableDimension)];
        Benchmark.ChangeFrequency = 8000;
        Benchmark.Budget = 7999;
    case 6
        Benchmark.ComponentDimensions = [4,2,2];
        FullySeparableDimension = 2;
        Benchmark.ComponentDimensions = [Benchmark.ComponentDimensions,ones(1,FullySeparableDimension)];
        Benchmark.ChangeFrequency = 8000;
        Benchmark.Budget = 7999;
    case 7
        Benchmark.ComponentDimensions = [4,2,2];
        FullySeparableDimension = 2;
        Benchmark.ComponentDimensions = [Benchmark.ComponentDimensions,ones(1,FullySeparableDimension)];
        Benchmark.ChangeFrequency = 8000;
        Benchmark.Budget = 7999;
    case 8
        Benchmark.ComponentDimensions = [4,2,2];
        FullySeparableDimension = 2;
        Benchmark.ComponentDimensions = [Benchmark.ComponentDimensions,ones(1,FullySeparableDimension)];
        Benchmark.ChangeFrequency = 8000;
        Benchmark.Budget = 7999;
    otherwise
        warning('Invalid secnario number. You must choose between scenarios 1 to 8')
end
Benchmark.Dimension = sum(Benchmark.ComponentDimensions);
Benchmark.PermutationMap = randperm(Benchmark.Dimension);
Benchmark.ConstraintNumber = ConstraintNumber;
Benchmark.UB = 50;
Benchmark.LB = -50;
Benchmark.MPBnumber = length(Benchmark.ComponentDimensions);
Benchmark.MPB = cell(1,Benchmark.MPBnumber);
Benchmark.EnvironmentNumber = 5;
%Benchmark.EnvironmentNumber = 100;
Benchmark.Environmentcounter = 1;%����������
for ii=1 : Benchmark.MPBnumber
    Benchmark.MPB{ii} = InitializingPeaks(Benchmark.ComponentDimensions(ii),ii,Benchmark.Dimension,ScenarioNumber,ConstraintNumber);
end

Benchmark.MaxEvals = Benchmark.ChangeFrequency * Benchmark.EnvironmentNumber;