function GA = GA_mating(GA,Benchmark)
% [FitSort,Fitkey] = sort(GA.Population.FitnessValue);
global  CurrentFE;
if isempty(CurrentFE)
    CurrentFE = 0;
end
x = GA.Population.X;
[SolutionNumber,~] = size(x);

% [min_vio,min_id] = min(GA.Population.ViolateValue);
% if length(find(GA.Population.ViolateValue==min_vio))>1
%         [GA.Population.GbestValue,BestPbestID] = max(GA.Population.FitnessValue(min_id,:));
% else
%     BestPbestID = min_id;
%     GA.Population.GbestValue = GA.Population.FitnessValue(min_id);
% end
% SaveX = GA.Population.X(BestPbestID,:);



 this_xy = randperm(SolutionNumber);
% this_fit = NaN(2*SolutionNumber,1);
for ii=1:2:SolutionNumber
    %     this_x = randperm(SolutionNumber,2);%�������ܻ����ظ��ĸ���
    %     this_y = randperm(SolutionNumber,2);
    
    parent_x = x(this_xy(ii),:);
    fit_parent_x = FitnessNum(parent_x',Benchmark);
    vio_parent_x =  ViolateNum(parent_x',Benchmark);
    x_key = this_xy(ii);
    parent_y = x(this_xy(ii+1),:);
    fit_parent_y = FitnessNum(parent_y',Benchmark);
    vio_parent_y =  ViolateNum(parent_y',Benchmark);
    y_key = this_xy(ii + 1);
  
    SBX_eta =  5*(1+CurrentFE)/Benchmark.ChangeFrequency;%Խ�󣬺�����������Ƶĸ���Խ��,һ������Ϊ1
%    SBX_eta =  1;
    SBX_r = rand;
    if SBX_r<=0.5
        SBX_gama = (2*SBX_r)^(1/(SBX_eta + 1));
    else
        SBX_gama = (1/(2*(1-SBX_r)))^(1/(SBX_eta + 1));
    end
    offspring_x1 = 0.5 * [(1 + SBX_gama) * parent_x + (1-  SBX_gama) * parent_y];
    offspring_x2 = 0.5 * [(1 -  SBX_gama) * parent_x + (1+ SBX_gama) * parent_y];
    this_key = randperm(GA.Dimension-1,1);
    for jj=1:GA.Dimension
        if jj<=this_key
            offspring_x3(jj)=parent_x(jj);
            offspring_x4(jj)=parent_y(jj);
        else
            offspring_x3(jj)=parent_y(jj);
            offspring_x4(jj)=parent_x(jj);
        end
    end
    
    fit_offx1 = FitnessNum(offspring_x1',Benchmark);
    vio_offx1 = ViolateNum(offspring_x1',Benchmark);
    fit_offx2 = FitnessNum(offspring_x2',Benchmark);
    vio_offx2 = ViolateNum(offspring_x2',Benchmark);
    fit_offx3 = FitnessNum(offspring_x3',Benchmark);
    vio_offx3 = ViolateNum(offspring_x3',Benchmark);
    fit_offx4 = FitnessNum(offspring_x4',Benchmark);
    vio_offx4 = ViolateNum(offspring_x4',Benchmark);
    %all_vio = [vio_parent_x,vio_parent_y,vio_offx1,vio_offx2,vio_offx3,vio_offx4];
    all_fit = [fit_parent_x,fit_parent_y,fit_offx1,fit_offx2,fit_offx3,fit_offx4];
    all_x =[GA.Population.X(x_key,:);GA.Population.X(y_key,:);offspring_x1;offspring_x2;offspring_x3;offspring_x4];
    all_vio = [vio_parent_x,vio_parent_y,vio_offx1,vio_offx2,vio_offx3,vio_offx4];
%     all_fit = [fit_offx1,fit_offx2,fit_offx3,fit_offx4];
%     all_x =[offspring_x1;offspring_x2;offspring_x3;offspring_x4];
%     all_vio = [vio_offx1,vio_offx2,vio_offx3,vio_offx4];
    min_v = min(all_vio);
    min_location = find(all_vio==min_v);
    [~,size_minv] = size(min_location);
    if size_minv>=2
        all_fit = all_fit(min_location);
        all_x = all_x(min_location,:);
        [FitSort,Fitkey] = sort(all_fit,'descend');
        Fitkey = Fitkey(1:2);
        GA.Population.X(x_key,:) = all_x(Fitkey(1),:);
        GA.Population.X(y_key,:) = all_x(Fitkey(2),:);
    else
        GA.Population.X(x_key,:) = all_x(min_location,:);
        if rand<1 * (1+CurrentFE)/Benchmark.ChangeFrequency%��һ�����ʽ����Υ��Լ���ĺ���Ӧ����ߵģ�����������������Ӧ��
            all_vio(min_location) = 9999;
            min_v = min(all_vio);
            min_location = find(all_vio==min_v);
            min_location = min_location(1);
            GA.Population.X(y_key,:) = all_x(min_location,:);
        else
            all_fit(min_location) = -999999;
            max_f = max(all_fit);
            max_location = find(all_fit==max_f);
            max_location = max_location(1);
            GA.Population.X(y_key,:) = all_x(max_location,:);
        end       
    end
end


% for kk = 1:SolutionNumber
%     GA.Population.X(SolutionNumber+kk,:) = (GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(1,GA.Dimension)));
% end

end
