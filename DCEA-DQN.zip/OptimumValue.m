function OptVal = OptimumValue(Benchmark)
fit = NaN(1,Benchmark.MPBnumber);
for ii=1 : Benchmark.MPBnumber
    fit(ii) = 0;
    this_key = -1;
         for jj = 1:Benchmark.MPB{ii}.PeakNumber
              if(Benchmark.MPB{ii}.PeaksHeight(jj)>fit(ii))
                  fit(ii) = Benchmark.MPB{ii}.PeaksHeight(jj);
              end
         end
%     for jj = 1:Benchmark.MPB{ii}.PeakNumber
%         if sum(ismember(Benchmark.MPB{ii}.FeasiblePeak,jj))~=0
%             if Benchmark.MPB{ii}.PeaksHeight(jj)>fit(ii)
%                 fit(ii) = Benchmark.MPB{ii}.PeaksHeight(jj);
%                 this_key = jj;
%             end
%         end
%     end
%     [~,PNum] = size(Benchmark.MPB{ii}.FeasiblePeak);
%     for pp = 1 : PNum
%         this_key = Benchmark.MPB{ii}.FeasiblePeak(pp);
%         
%         for jj = 1:Benchmark.MPB{ii}.PeakNumber
%             if sum(ismember(Benchmark.MPB{ii}.FeasiblePeak,jj))==0%jj~=this_key
%                 this_num = pdist2(Benchmark.MPB{ii}.PeaksPosition(this_key,:),Benchmark.MPB{ii}.PeaksPosition(jj,:));
%                 if this_num - Benchmark.MPB{ii}.radius <= 0
%                     if Benchmark.MPB{ii}.PeaksHeight(jj)>fit(ii)
%                         fit(ii) = Benchmark.MPB{ii}.PeaksHeight(jj);
%                     end
%                 end
%             end
%         end
%     end
    fit(ii) = fit(ii)*Benchmark.MPB{ii}.Weight;
end
OptVal = sum(fit);
end