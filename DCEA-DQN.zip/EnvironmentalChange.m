function MPB = EnvironmentalChange(MPB,MPBnumber,ConstraintNumber)
global MaxPeakNum;
MaxPeakNum = NaN;
for ii=1 : MPBnumber
    for jj = 1: MPB{ii}.PeakNumber
        %/* Change peak center location */
        R = randn(1,MPB{ii}.Dimension);
        Shift = MPB{ii}.ShiftSeverity  * (R/pdist2(R,zeros(size(R))));
        for kk = 1 : MPB{ii}.Dimension
            if ((MPB{ii}.PeaksPosition(jj,kk) + Shift(kk)) < MPB{ii}.MinCoordinate)
                MPB{ii}.PeaksPosition(jj,kk) = (2 * MPB{ii}.MinCoordinate) - MPB{ii}.PeaksPosition(jj,kk) - Shift(kk);
            elseif ((MPB{ii}.PeaksPosition(jj,kk) + Shift(kk)) > MPB{ii}.MaxCoordinate)
                MPB{ii}.PeaksPosition(jj,kk) = (2 * MPB{ii}.MaxCoordinate) - MPB{ii}.PeaksPosition(jj,kk)	- Shift(kk);
            else
                MPB{ii}.PeaksPosition(jj,kk) = MPB{ii}.PeaksPosition(jj,kk) + Shift(kk);
            end
        end
        
        %/* change width */
        if MPB{ii}.EllipticalPeaks==0
            offset = MPB{ii}.WidthSeverity * randn;
            for kk = 1 : MPB{ii}.Dimension
                if ((MPB{ii}.PeaksWidth(jj,kk) + offset) < MPB{ii}.MinWidth)
                    MPB{ii}.PeaksWidth(jj,kk) = 2 * MPB{ii}.MinWidth - MPB{ii}.PeaksWidth(jj,kk) - offset;
                elseif ((MPB{ii}.PeaksWidth(jj,kk) + offset) > MPB{ii}.MaxWidth)
                    MPB{ii}.PeaksWidth(jj,kk) = 2 * MPB{ii}.MaxWidth -MPB{ii}.PeaksWidth(jj,kk) - offset;
                else
                    MPB{ii}.PeaksWidth(jj,kk) = MPB{ii}.PeaksWidth(jj,kk) + offset;
                end
            end
        else
            offset = MPB{ii}.WidthSeverity * randn(1,MPB{ii}.Dimension);
            for kk = 1 : MPB{ii}.Dimension
                if ((MPB{ii}.PeaksWidth(jj,kk) + offset(kk)) < MPB{ii}.MinWidth)
                    MPB{ii}.PeaksWidth(jj,kk) = 2 * MPB{ii}.MinWidth - MPB{ii}.PeaksWidth(jj,kk) - offset(kk);
                elseif ((MPB{ii}.PeaksWidth(jj,kk) + offset(kk)) > MPB{ii}.MaxWidth)
                    MPB{ii}.PeaksWidth(jj,kk) = 2 * MPB{ii}.MaxWidth -MPB{ii}.PeaksWidth(jj,kk) - offset(kk);
                else
                    MPB{ii}.PeaksWidth(jj,kk) = MPB{ii}.PeaksWidth(jj,kk) + offset(kk);
                end
            end
        end
        %/* change height */
        offset = MPB{ii}.HeightSeverity * randn;
        if ((MPB{ii}.PeaksHeight(jj) + offset) < MPB{ii}.MinHeight)
            MPB{ii}.PeaksHeight(jj) = 2 * MPB{ii}.MinHeight - MPB{ii}.PeaksHeight(jj) - offset;
        elseif ((MPB{ii}.PeaksHeight(jj) + offset) > MPB{ii}.MaxHeight)
            MPB{ii}.PeaksHeight(jj) = 2 * MPB{ii}.MaxHeight - MPB{ii}.PeaksHeight(jj) - offset;
        else
            MPB{ii}.PeaksHeight(jj) = MPB{ii}.PeaksHeight(jj) + offset;
        end
        %/* change Eta */
        offset = MPB{ii}.EtaSeverity * randn(1,4);
        for kk=1 : 4
            if ((MPB{ii}.eta(jj,kk) + offset(kk)) < MPB{ii}.MinEta)
                MPB{ii}.eta(jj,kk) = 2 * MPB{ii}.MinEta - MPB{ii}.eta(jj,kk) - offset(kk);
            elseif ((MPB{ii}.eta(jj,kk) + offset(kk)) > MPB{ii}.MaxEta)
                MPB{ii}.eta(jj,kk) = 2 * MPB{ii}.MaxEta - MPB{ii}.eta(jj,kk) - offset(kk);
            else
                MPB{ii}.eta(jj,kk) = MPB{ii}.eta(jj,kk) + offset(kk);
            end
        end
        %/* change tau */
        offset = MPB{ii}.TauSeverity * randn;
        if ((MPB{ii}.tau(jj) + offset) < MPB{ii}.MinTau)
            MPB{ii}.tau(jj) = 2 * MPB{ii}.MinTau - MPB{ii}.tau(jj) - offset;
        elseif ((MPB{ii}.tau(jj) + offset) > MPB{ii}.MaxTau)
            MPB{ii}.tau(jj) = 2 * MPB{ii}.MaxTau - MPB{ii}.tau(jj) - offset;
        else
            MPB{ii}.tau(jj) = MPB{ii}.tau(jj) + offset;
        end
        %/* change angle */
        offset = MPB{ii}.AngleSeverity * randn;
        if ((MPB{ii}.PeaksAngle(jj) + offset) < MPB{ii}.MinAngle)
            MPB{ii}.PeaksAngle(jj) = 2 * MPB{ii}.MinAngle - MPB{ii}.PeaksAngle(jj) - offset;
        elseif ((MPB{ii}.PeaksAngle(jj) + offset) > MPB{ii}.MaxAngle)
            MPB{ii}.PeaksAngle(jj) = 2 * MPB{ii}.MaxAngle - MPB{ii}.PeaksAngle(jj) - offset;
        else
            MPB{ii}.PeaksAngle(jj) = MPB{ii}.PeaksAngle(jj) + offset;
        end
        %/* change rotation matrix */
        if MPB{ii}.Dimension>1
            MPB{ii}.RotationMatrix(:,:,jj) = MPB{ii}.InitialRotationMatrix(:,:,jj) * Rotation(MPB{ii}.PeaksAngle(jj),MPB{ii}.Dimension);
        end
    end
    switch ConstraintNumber
        case 1
            %disp(['feasible peaks ��',num2str(MPB{ii}.FeasiblePeak)]);
            this_height = max(MPB{ii}.PeaksHeight(MPB{ii}.FeasiblePeak));
            for kk = 1 : MPB{ii}.PeakNumber
                if sum(ismember(MPB{ii}.FeasiblePeak,kk))==0
                    while MPB{ii}.PeaksHeight(kk)>this_height
                        MPB{ii}.PeaksHeight(kk) = MPB{ii}.MinHeight + (MPB{ii}.MaxHeight-MPB{ii}.MinHeight)*rand;
                    end
                end
            end
        case 2
            FixedNumber = randperm(MPB{ii}.PeakNumber);
            FixedNumber = FixedNumber(1,1:3);
            [~,pos] = sort(MPB{ii}.PeaksHeight(:));
            len = length(pos);
            best_peak = pos(len);
            if sum(ismember(FixedNumber,best_peak))==0
                FixedNumber(1) = best_peak;
            end
            MPB{ii}.FeasiblePeak = FixedNumber;
            %disp(['feasible peaks ��',num2str(MPB{ii}.FeasiblePeak)]);
        case 3
            [~,pos] = sort(MPB{ii}.PeaksHeight(:));
            len = length(pos);
            MPB{ii}.FeasiblePeak = pos((len-2):len);
            %disp(['feasible peaks ��',num2str(MPB{ii}.FeasiblePeak')]);
    end
% for kk = 1:MPB{ii}.PeakNumber
%      if sum(ismember(MPB{ii}.FeasiblePeak,kk)) == 0
%          this_flag = 0;
%          for jj = 1:3
% %              if MPB{ii}.PeaksHeight(kk)>MPB{ii}.PeaksHeight(MPB{ii}.FeasiblePeak(jj))
%                  if pdist2(MPB{ii}.PeaksPosition(MPB{ii}.FeasiblePeak(jj),:),MPB{ii}.PeaksPosition(kk,:))>MPB{ii}.radius && pdist2(MPB{ii}.PeaksPosition(MPB{ii}.FeasiblePeak(jj),:),MPB{ii}.PeaksPosition(kk,:))<= (MPB{ii}.radius + 12)%max(MPB{ii}.PeaksWidth(kk,:))
%                      this_flag = 1;
%                  end
% %              end
%          end
%          while this_flag
%              MPB{ii}.PeaksPosition(kk,:) = MPB{ii}.MinCoordinate + ((MPB{ii}.MaxCoordinate-MPB{ii}.MinCoordinate)*rand(1,MPB{ii}.Dimension));
%              temple_flag = 0;
%              for jj = 1:3
%                  if pdist2(MPB{ii}.PeaksPosition(MPB{ii}.FeasiblePeak(jj),:),MPB{ii}.PeaksPosition(kk,:))>MPB{ii}.radius && pdist2(MPB{ii}.PeaksPosition(MPB{ii}.FeasiblePeak(jj),:),MPB{ii}.PeaksPosition(kk,:))<= (MPB{ii}.radius + 12)%max(MPB{ii}.PeaksWidth(kk,:))
%                      temple_flag = temple_flag + 1;
%                  end
%              end
%              if temple_flag == 0
%                  this_flag = 0;
%              end
%          end
%      end
% end
    [~,this_height_pos] = max(MPB{ii}.PeaksHeight(MPB{ii}.FeasiblePeak));
    if isnan(MaxPeakNum)
        MaxPeakNum = MPB{ii}.FeasiblePeak(this_height_pos);
    else
        MaxPeakNum = [MaxPeakNum;MPB{ii}.FeasiblePeak(this_height_pos)];
    end
end