function GA = GAmutation_RL(GA,Benchmark)%��η�ֹ����ֲ�����?
global DQNet1 DQNet1_target;
if isempty(DQNet1)
    DQNet1=fitnet([32,16]);
    Iniset=zeros(70,400);  
    for i=1:40
        k=0; 
        for j=1:60
            if k>=10
                if k==10
                    Iniset(j,i)=(unidrnd(200)-100)*0.01;%fit
                else
                    Iniset(j,i)=(unidrnd(200)-100)*0.01;%vio
                  k = 0;  
                end                            
            else 
                Iniset(j,i)=(unidrnd(200)-100)*0.01;
                k = k + 1; 
                
            end
        end
        for j=60:70
            Iniset(j,i)=(unidrnd(200)-100)*0.01;
        end
    end
    clear i j k;
    DQNet1=train(DQNet1,Iniset(1:55,:),Iniset(56:65,:));
     for i=1:40
        k=0;
        for j=1:60
            if k>=10
                if k==10
                    Iniset(j,i)=(unidrnd(200)-100)*0.01;%fit
                else
                    Iniset(j,i)=(unidrnd(200)-100)*0.01;%vio
                  k = 0;  
                end                            
            else
                Iniset(j,i)=(unidrnd(200)-100)*0.01;
                k = k + 1; 
                %Iniset(i,j)=DQNet1+DQNet1;
            end
        end
        for j=60:70
            Iniset(j,i)=(unidrnd(200)-100)*0.01;
        end
    end
    DQNet1_target=DQNet1;
end

end
