function [GA, CtrlFlag,Benchmark] = GAprocedure(GA,Benchmark)
% persistent this_id;
global  CurrentFE GA_flag GlobalOpt mate_state_flag;
CtrlFlag=0; %#ok<NASGU>
if isempty(CurrentFE)
    GA_flag = 0;
end
% if isempty(this_id)
%     this_id = 1;
% end
GA.SaveX = GA.Population.X;
%GA = GA_mating(GA,Benchmark);
GA = GA_mating_RL(GA,Benchmark);%������ӽ�ʹ��RL


GA = GAmutation(GA,Benchmark);

if CurrentFE/Benchmark.Budget<0.7%����3500�κ�����С��������������%0.7
    GA = GAnichi(GA,Benchmark);
else
    if GA_flag == 0
        GA_flag = 1;
        GA = GAselect(GA,Benchmark);%ѡ��
        GA.Population.TestPop = GA.Population.X;
        GA.Population.TestFit = GA.Population.FitnessValue;
        for kk = 1:GA.PopulationSize
            this_fitnessvalue(kk) = FitnessNum(GA.Population.X(kk,:)',Benchmark);
            this_peakvalue(:,kk) = PeakNum(GA.Population.X(kk,:),Benchmark);
        end
    else
        GA = GAselect(GA,Benchmark);
    end
end


for jj=1 : GA.PopulationSize
    for kk=1 : GA.Dimension
        if GA.Population.X(jj,kk) > GA.MaxCoordinate
            GA.Population.X(jj,kk) = GA.MaxCoordinate;
        elseif GA.Population.X(jj,kk) < GA.MinCoordinate
            GA.Population.X(jj,kk) = GA.MinCoordinate;
        end
    end
end
[GA.Population.FitnessValue,CtrlFlag,Benchmark] = benchmark_func(GA.Population.X,Benchmark);
for jj=1 : GA.PopulationSize
    GA.Population.ViolateValue(jj) = ViolateNum(GA.Population.X(jj,:)',Benchmark);
end
if CtrlFlag~=0
    return;
end

for jj=1 : GA.PopulationSize
    if GA.Population.ViolateValue(jj) == GA.Population.PbestViolateValue(jj)
        if GA.Population.FitnessValue(jj) > GA.Population.PbestValue(jj)
            GA.Population.PbestValue(jj) = GA.Population.FitnessValue(jj);
            GA.Population.PbestPosition(jj,:) = GA.Population.X(jj,:);
        end
    elseif GA.Population.ViolateValue(jj) < GA.Population.PbestViolateValue(jj)
        GA.Population.PbestViolateValue(jj) = GA.Population.ViolateValue(jj);
        GA.Population.PbestValue(jj) = GA.Population.FitnessValue(jj);
        GA.Population.PbestPosition(jj,:) = GA.Population.X(jj,:);
    end
end
% [BestPbestValue,BestPbestID] = max(GA.Population.PbestValue);
[min_vio,min_id] = min(GA.Population.ViolateValue);
GA.Population.Gminvlo = min_vio;
if length(find(GA.Population.ViolateValue==min_vio))>1
    F_key = find(GA.Population.ViolateValue==min_vio);
    [GA.Population.GbestValue,BestPbestID] = max(GA.Population.FitnessValue(F_key));
    BestPbestID = F_key(BestPbestID);
else
    BestPbestID = min_id;
    GA.Population.GbestValue = GA.Population.FitnessValue(min_id);
end


mate_state_flag = state_of_population(GA.Population.X,GA.PopulationSize,GA.Population.GbestValue,GA.fit_best_pre,min_vio,GA.vlo_min_pre);



if ViolateNum(GA.Population.X(BestPbestID,:)',Benchmark)==0
%     if CurrentFE > 4900
%         RFNum(GA.Population.X(BestPbestID,:)',Benchmark)
%     end
    disp(GlobalOpt-GA.Population.GbestValue);
else
    disp(['���Žⲻ�ڿ���������']);
end


end


% function fit = RFNum(x,Benchmark)
% ldim = 1;
% fit = 0;
% for ii=1 : Benchmark.MPBnumber
%     solution = x;
%     solution = x(Benchmark.PermutationMap(ldim:ldim+Benchmark.MPB{ii}.Dimension-1));%������
%     f=NaN(1,Benchmark.MPBnumber);
%     if ~isnan(solution)
%         for k=1 : Benchmark.MPB{ii}.PeakNumber
%             a = Transform((solution - Benchmark.MPB{ii}.PeaksPosition(k,:)')'*Benchmark.MPB{ii}.RotationMatrix(:,:,k)',Benchmark.MPB{ii}.tau(k),Benchmark.MPB{ii}.eta(k,:));
%             b = Transform(Benchmark.MPB{ii}.RotationMatrix(:,:,k) * (solution - Benchmark.MPB{ii}.PeaksPosition(k,:)'),Benchmark.MPB{ii}.tau(k),Benchmark.MPB{ii}.eta(k,:));
%             f(k) = Benchmark.MPB{ii}.PeaksHeight(k) - sqrt( a * diag(Benchmark.MPB{ii}.PeaksWidth(k,:).^2) * b);
%         end
%         [f,~] = max(f);
%         f
%         Benchmark.MPB{ii}.Weight
%         f = f * Benchmark.MPB{ii}.Weight;
%     end
%     ldim = ldim + Benchmark.MPB{ii}.Dimension;
%     fit = fit + f;
% end
% end


function this_flag = state_of_population(x,SolutionNumber,GbestValue,fit_best_pre,vlo_min,vlo_min_pre)
global Div_0 GlobalOpt IC0;
avg_x = mean(x);
this_add = pdist2(x, avg_x);
last_add = 0;
for m=1:SolutionNumber
    last_add = last_add + this_add(m)^2 / SolutionNumber;
end
last_add = sqrt(last_add);
flag_1 = last_add/Div_0;%[0,1]


% if vlo_min_pre == 0
%     flag_2 = abs((GlobalOpt - GbestValue)/fit_best_pre);
% else
%     flag_2 = (abs((GlobalOpt - GbestValue)/fit_best_pre) + vlo_min/vlo_min_pre)/2;
% end
flag_2 = abs((GlobalOpt - GbestValue)/fit_best_pre);

if vlo_min_pre == 0
    flag_2 = flag_2/IC0;
else
    flag_2 = (flag_2/IC0 + vlo_min/vlo_min_pre)/2;
end

if flag_1<=0.5
    if flag_2<0.5
        this_flag= 1;
    elseif flag_2<1
        this_flag= 2;
    else
        this_flag= 3;
    end
else
    if flag_2<0.5
        this_flag= 4;
    elseif flag_2<1
        this_flag= 5;
    else
        this_flag= 6;
    end
end

end