function [result,CtrlFlag,Benchmark,ViolateNum] = benchmark_func(X,Benchmark)
%%%%%%%%%%%%global  Benchmark MPB evals ChangeFrequency
global OfflineError CurrentFE GA_flag GlobalOpt state_flag;
persistent evals  FitnessHistory Optimum;%�˳��������Ա�����ı���
CtrlFlag = 0;
if isempty(evals)
    evals = 0;
    CurrentFE = 0;
    FitnessHistory = NaN(1,Benchmark.MaxEvals);
end
CurrentFE
if isempty(Optimum)
    Optimum = OptimumValue(Benchmark);
end
[SolutionNumber,~] = size(X);
result = NaN(SolutionNumber,1);
for jj=1 : SolutionNumber
    x = X(jj,:)';
    result(jj) = FitnessNum(x,Benchmark);
%     ViolateNum(jj) = ViolateNum(x,Benchmark);
    evals = evals + 1;%ÿ����һ����+1
    CurrentFE = CurrentFE + 1;%ÿ����һ����+1
    CurrentError = Optimum - result(jj);
    if CurrentFE > 1
        if FitnessHistory(evals-1)<CurrentError
            FitnessHistory(evals) = FitnessHistory(evals-1);
        else
            FitnessHistory(evals) = CurrentError;
        end
    else
        FitnessHistory(evals) =   CurrentError;
    end
    
    if evals == Benchmark.MaxEvals%���������ܵĽ�������
        CtrlFlag = 3;
        clear evals;
        OfflineError = mean(FitnessHistory);
        break;
    end
    if ~rem(evals,Benchmark.ChangeFrequency)%���������������Ϊ0�򡾴������˻����ı��ʱ���ˡ�
        
%         Benchmark.Environmentcounter = Benchmark.Environmentcounter +1;
        %Benchmark.MPB = EnvironmentalChange(Benchmark.MPB,Benchmark.MPBnumber,Benchmark.ConstraintNumber);
        if Benchmark.Environmentcounter+ 1 <=Benchmark.EnvironmentNumber
            Benchmark.Environmentcounter = Benchmark.Environmentcounter +1;
            Benchmark.MPB = Benchmark.ALLMPB(Benchmark.Environmentcounter,:);
        end
        GlobalOpt = OptimumValue(Benchmark);
        state_flag = randperm(4,1);
        
        clear Optimum;
        CtrlFlag = 1;
        CurrentFE = 0;
        GA_flag = 0;
        
        break;
    end
    if CurrentFE == Benchmark.Budget
        CtrlFlag = 2;
        break;
    end
end
end





