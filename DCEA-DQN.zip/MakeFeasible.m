function [Last_X,result,Violate] = MakeFeasible(GA,Benchmark,MinCoordinate,MaxCoordinate,Dimension)
Ga_X = GA.Population.X;
[SolutionNumber,~] = size(Ga_X);
result = ones(1,SolutionNumber)*-999;
Violate = ones(1,SolutionNumber)* 999;
AvailableNum = 0;
for gg = 1 : SolutionNumber
    Violate(gg) = ViolateNum(Ga_X(gg,:)',Benchmark);
    result(gg) = FitnessNum(Ga_X(gg,:)',Benchmark);
end
for ii = 1:SolutionNumber-1
    for jj = ii + 1 :SolutionNumber
        kk = 0;
        while  sum((Ga_X(ii,:)-Ga_X(jj,:)).*(Ga_X(ii,:)-Ga_X(jj,:))) - (GA.L*3)^2 <=0
            Ga_X(jj,:) = GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(1 ,GA.Dimension));           
            kk = kk + 1;
            if kk>=1000
               continue; 
            end
        end
    end
end
Last_X = GA.Population.X;
end












