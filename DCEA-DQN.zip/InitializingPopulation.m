function [GA] = InitializingPopulation(GA,Benchmark)
% rng('shuffle');
global Div_0 mate_state_flag IC0 GlobalOpt;
GA.Gbest_past_environment = NaN(1,GA.Dimension);
%Ga.Population = zeros(PopulationSize,Dimension);
%Ga.Shifts = [];%��������ĺ��壿
GA.Population.X = GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(GA.PopulationSize ,GA.Dimension));

[GA.Population.X,GA.Population.FitnessValue,GA.Population.ViolateValue] = MakeFeasible(GA,Benchmark,GA.MinCoordinate,GA.MaxCoordinate,GA.Dimension);

x = GA.Population.X;
avg_x = mean(x);
this_add = pdist2(x, avg_x);
Div_0 = 0;
for m=1:GA.PopulationSize
    Div_0 = Div_0 + this_add(m)^2 / GA.PopulationSize;
end
Div_0 = sqrt(Div_0);



mate_state_flag = randperm(4,1);

% [Ga.FitnessValue,CtrlFlag,Benchmark] = benchmark_func(Ga.X,Benchmark);
GA.Population.PbestPosition = GA.Population.X;
GA.Population.PbestValue = GA.Population.FitnessValue;
GA.Population.PbestViolateValue = GA.Population.ViolateValue;
% [GA.Population.GbestValue,GbestID] = max(GA.Population.PbestValue);
[min_vio,min_id] = min(GA.Population.ViolateValue);
GA.Population.Gminvlo = min_vio;
if length(find(GA.Population.ViolateValue==min_vio))>1
        [GA.Population.GbestValue,GbestID] = max(GA.Population.FitnessValue(min_id,:));
else
    GbestID = min_id;
    GA.Population.GbestValue = GA.Population.FitnessValue(min_id);
end


IC0 = abs((GlobalOpt - GA.Population.GbestValue)/GA.Population.GbestValue);
% if min_vio == 0
%     IC0 = abs(GlobalOpt - GA.Population.GbestValue)/abs(GA.Population.GbestValue);
% else
%     IC0 = (abs(GlobalOpt - GA.Population.GbestValue)/abs(GA.Population.GbestValue) + min_vio/min_vio)/2;
% end


GA.Population.GbestPosition = GA.Population.PbestPosition(GbestID,:);
end