function last_peak = PeakNum(x,Benchmark)
ldim = 1;
last_peak = NaN;
for ii=1 : Benchmark.MPBnumber
    solution = x;
    solution = x(Benchmark.PermutationMap(ldim:ldim+Benchmark.MPB{ii}.Dimension-1));%������
    if ~isnan(solution)
        for k=1 : Benchmark.MPB{ii}.PeakNumber
            k_flag = 0;
            if sum(ismember(Benchmark.MPB{ii}.FeasiblePeak,k))~=0
                if sum((solution-Benchmark.MPB{ii}.PeaksPosition(k,:)).*(solution-Benchmark.MPB{ii}.PeaksPosition(k,:)))<=(Benchmark.MPB{ii}.radius)^2
                    k_flag = 1;
                    this_peak = k;
                end
            end
        end
        if k_flag ~= 1
            for k=1 : Benchmark.MPB{ii}.PeakNumber
                f(k) = sum((solution-Benchmark.MPB{ii}.PeaksPosition(k,:)).*(solution-Benchmark.MPB{ii}.PeaksPosition(k,:)));
            end
             [~,this_peak] = min(f);
        end       
    end
    ldim = ldim + Benchmark.MPB{ii}.Dimension;
    if isnan(last_peak)
        last_peak = this_peak;
    else
        last_peak = [last_peak;this_peak];
    end
end
end