function GA = GAmutation(GA,Benchmark)%��η�ֹ����ֲ�����?
global  CurrentFE;
x = GA.Population.X;

% Epcl = rand * 4*(1-CurrentFE/Benchmark.Budget);%̽���Ĳ���[��Ҫһ�����õ�̽������ֵ������Ǹ���������Ӧ]
%Epcl = rand * 4;
[SolutionNumber,~] = size(x);
if CurrentFE<=6000
    SolutionNumber = round(SolutionNumber * (1+CurrentFE)/6000);
else
    SolutionNumber = round(SolutionNumber * (6000-(CurrentFE-6000))/6000);
end
%SolutionNumber = round(SolutionNumber * (1+CurrentFE)/Benchmark.ChangeFrequency);
for ii=1:SolutionNumber
    for jj = 1: 2 * GA.Dimension
        this_x(jj,:) = x(ii,:);
    end
    for pp = 1:GA.Dimension
        Epcl = rand * log10(Benchmark.ChangeFrequency-CurrentFE+1);
        this_x(pp,pp) = x(pp,pp) + Epcl;
        this_x(GA.Dimension + pp,pp) = x(pp,pp) - Epcl;
        fit_this_x(pp) = FitnessNum(this_x(pp,:)',Benchmark);
        vio_this_x(pp) = ViolateNum(this_x(pp,:)',Benchmark);
        fit_this_x(GA.Dimension + pp) = FitnessNum(this_x(GA.Dimension + pp,:)',Benchmark);
        vio_this_x(GA.Dimension + pp) = ViolateNum(this_x(GA.Dimension + pp,:)',Benchmark);
    end
    this_x(2 * GA.Dimension + 1,:) = x(ii,:);
    fit_this_x(2 * GA.Dimension + 1) = FitnessNum(x(ii,:)',Benchmark);
    vio_this_x(2 * GA.Dimension + 1) = ViolateNum(x(ii,:)',Benchmark);
    this_key = randperm(GA.Dimension);
    this_key = this_key(1);
    this_x(2 * GA.Dimension + 2,this_key) = GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand);
    fit_this_x(2 * GA.Dimension + 2) = FitnessNum(this_x(2 * GA.Dimension + 2,:)',Benchmark);
    vio_this_x(2 * GA.Dimension + 2) = ViolateNum(this_x(2 * GA.Dimension + 2,:)',Benchmark);
    min_v = min(vio_this_x);
    min_location = find(vio_this_x==min_v);
    [~,size_minv] = size(min_location);
    if size_minv>=2
        fit_this_x = fit_this_x(min_location);
        this_x = this_x(min_location,:);
        [FitSort,Fitkey] = sort(fit_this_x,'descend');
        Fitkey = Fitkey(1);
        GA.Population.X(ii,:) = this_x(Fitkey(1),:);
        %         GA.Population.FitnessValue(ii) = FitSort(1);
    else
        GA.Population.X(ii,:) = this_x(min_location,:);
        %         GA.Population.FitnessValue(ii) = fit_this_x(min_location);
    end
    
    
    %     [~,x_key] = max(fit_this_x);
    %     GA.Population.X(ii,:) = this_x(x_key,:);
end

end
