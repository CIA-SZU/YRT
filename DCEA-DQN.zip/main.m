clear all;close all;clc;
global OfflineError MaxPeakNum GlobalOpt Q_mating_table Q_reacting_table;
global DQNet1 DQNet1_target;
RunNumber = 31;
FinalResults = NaN(3,RunNumber);
last_result = -1;%
Q_mating_table = ones(6,3);
Q_reacting_table = ones(4,3);
for test=1 : RunNumber
    rng(test);%This random seed setting is used to initialize the GMPB
    CtrlFlag = 0;%   This is a flag that controls the optimizer when an environmental change has happended,
    %   or when the solution needs to be fetched/implemented (after using the predefined FE budget
    %   in each environment), and when the optimization process has been finished.
    ScenarioNumber = 1;%1-8
    ConstraintNumber = 1;%1-3  
    
    Benchmark = BenchmarkGenerator(ScenarioNumber,ConstraintNumber);
    
    GlobalOpt = OptimumValue(Benchmark);
    
    
    AllMpb(1,:) = Benchmark.MPB;
    for ii = 2 :Benchmark.EnvironmentNumber
        AllMpb(ii,:) = EnvironmentalChange(AllMpb(ii- 1,:),Benchmark.MPBnumber,Benchmark.ConstraintNumber);
    end
    Benchmark.ALLMPB = AllMpb;
    %     Benchmark.MPB = Benchmark.ALLMPB(3,:);
    %     Benchmark.MPB = Benchmark.ALLMPB(2,:);
    %     GlobalOpt = OptimumValue(Benchmark);
    %     while 1
    %         Benchmark.MPB = EnvironmentalChange(Benchmark.MPB,Benchmark.MPBnumber,Benchmark.ConstraintNumber);
    %         GlobalOpt = OptimumValue(Benchmark);
    %     end
    rng('shuffle');%Set a random seed for the optimizer
    %rand('seed',sum(100* clock));
    
    %% Optimizer part
    Results = NaN(2,Benchmark.EnvironmentNumber);
    GA.Dimension = Benchmark.Dimension;
    GA.PopulationSize = 50;
    GA.RestingPercentage = 0.2;
    GA.NumberOfRestingPopulations = ceil(GA.PopulationSize*GA.RestingPercentage);
    GA.MaxCoordinate   = Benchmark.UB;
    GA.MinCoordinate = Benchmark.LB;
    GA.mutationProb = 0.05;
    GA.FeasiblePercent = 0.8;
    GA.NumberOfFeasiblePopulations = ceil(GA.PopulationSize*GA.FeasiblePercent);
    GA.SaveTransferPop = NaN;
    GA.SaveTransferFit = NaN;
    %GA.L = 10;
    GA.L = 45;%С������ӵ���뾶
    [GA] = InitializingPopulation(GA,Benchmark);
    %[GA.Population,~,~] = InitializingGA(GA.Dimension,GA.MinCoordinate,GA.MaxCoordinate,GA.PopulationSize,Benchmark);
    %Ѱ�ҿ�������
    if isempty(DQNet1)
        %         TextX = [GA.Population.X,GA.Population.FitnessValue',GA.Population.ViolateValue'];
        %         t=[1];
        %         [pn,inputps]=mapminmax(TextX);
        %         [tn,outputps]=mapminmax(t);
        %         DQNet1=newff(minmax(pn),[32,16,1]);
        %         %[DQNet1,tr]=train(DQNet1,pn,tn);
        %         DQNet1_target=DQNet1;
        DQNet1.net = fitnet([32,16,1],'trainlm');
        DQNet1.net_prev = DQNet1.net;
        DQNet1.net.trainParam.lr = 0.1;
        DQNet1.net.trainParam.epochs = 10;
        DQNet1.net.trainParam.showWindow = true;
        DQNet1.net.trainParam.lr_dec = 0.8;
        DQNet1.net = train(DQNet1.net,rand(10,25),rand(length(4),25));
        DQNet1.netWeights = getwb(DQNet1.net);
    end
    %% main loop of the optimizer
    while 1
        if CtrlFlag==1%When an environmental change has happened
            GA.Population.X2 = GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(2 * GA.PopulationSize ,GA.Dimension));
            for ii = 1:2 * GA.PopulationSize
                GA.Population.X2RealVio(ii,1) = RealViolateNum(GA.Population.X2(ii,:),Benchmark);
                GA.Population.X2RealVio(ii,2) = FitnessNum(GA.Population.X2(ii,:)',Benchmark);
            end
            GA = Reaction(GA,Benchmark);
            %         GA = TransferReaction(GA,Benchmark);
            CtrlFlag = 0;
        elseif CtrlFlag==2%When the computational budget in the current environment has been finished
            Results(1,Benchmark.Environmentcounter) = GA.Population.GbestValue;
            Results(2,Benchmark.Environmentcounter) = GlobalOpt;%OptimumValue(Benchmark)
            last_result = GlobalOpt - GA.Population.GbestValue;
            last_pop = GA.Population.TestPop;
            
      
            GA.Population.X1 = GA.MinCoordinate + ((GA.MaxCoordinate-GA.MinCoordinate).*rand(2 * GA.PopulationSize ,GA.Dimension));
            for ii = 1: 2 * GA.PopulationSize
                GA.Population.X1RealVio(ii,1) = RealViolateNum(GA.Population.X1(ii,:),Benchmark);
                GA.Population.X1RealVio(ii,2) = FitnessNum(GA.Population.X1(ii,:)',Benchmark);
            end
            CtrlFlag = 0;
            disp([ScenarioNumber,test,Benchmark.Environmentcounter]);
        end
        if  CtrlFlag==3%When termination criteria has been met
            break;
        end
    end  
    FinalResults(1,test) = mean(Results(1,:));
    FinalResults(2,test) = mean(Results(2,:));
    FinalResults(3,test) = OfflineError;
    
end



