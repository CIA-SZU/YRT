function fit = FitnessNum(x,Benchmark)
ldim = 1;
fit = 0;
for ii=1 : Benchmark.MPBnumber
    solution = x;
    solution = x(Benchmark.PermutationMap(ldim:ldim+Benchmark.MPB{ii}.Dimension-1));%������
    f=NaN(1,Benchmark.MPBnumber);
    if ~isnan(solution)
        for k=1 : Benchmark.MPB{ii}.PeakNumber
            a = Transform((solution - Benchmark.MPB{ii}.PeaksPosition(k,:)')'*Benchmark.MPB{ii}.RotationMatrix(:,:,k)',Benchmark.MPB{ii}.tau(k),Benchmark.MPB{ii}.eta(k,:));
            b = Transform(Benchmark.MPB{ii}.RotationMatrix(:,:,k) * (solution - Benchmark.MPB{ii}.PeaksPosition(k,:)'),Benchmark.MPB{ii}.tau(k),Benchmark.MPB{ii}.eta(k,:));
            f(k) = Benchmark.MPB{ii}.PeaksHeight(k) - sqrt( a * diag(Benchmark.MPB{ii}.PeaksWidth(k,:).^2) * b);
        end
        [f,~] = max(f);
        f = f * Benchmark.MPB{ii}.Weight;
    end
    ldim = ldim + Benchmark.MPB{ii}.Dimension;
    fit = fit + f;
end
end