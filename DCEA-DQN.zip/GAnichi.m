function GA = GAnichi(GA,Benchmark)
X = [GA.Population.X;GA.SaveX];
% X = unique(X,'rows','stable');
[SolutionNumber,~] = size(X);
for kk = 1 : SolutionNumber
    this_fitnessvalue(kk) = FitnessNum(X(kk,:)',Benchmark);
    this_violatevalue(kk) = ViolateNum(X(kk,:)',Benchmark);
end
for ii = 1:SolutionNumber-1
    for jj = ii + 1 :SolutionNumber
        if  sum((X(ii,:)-X(jj,:)).*(X(ii,:)-X(jj,:))) - (GA.L)^2 <=0
            if this_violatevalue(ii) == this_violatevalue(jj)
                if this_fitnessvalue(ii)>=this_fitnessvalue(jj)
                    this_fitnessvalue(jj) = this_fitnessvalue(jj) - 9999;%ʩ�ӷ�����
                    this_violatevalue(jj) = this_violatevalue(jj) + 9999;
                else
                    this_fitnessvalue(ii) = this_fitnessvalue(ii) - 9999;
                    this_violatevalue(ii) = this_violatevalue(ii) + 9999;
                end
            else
                if this_violatevalue(ii) < this_violatevalue(jj)
                    this_violatevalue(jj) = this_violatevalue(jj) + 9999;
                    this_fitnessvalue(jj) = this_fitnessvalue(jj) - 9999;
                else
                    this_violatevalue(ii) = this_violatevalue(ii) + 9999;
                    this_fitnessvalue(ii) = this_fitnessvalue(ii) - 9999;
                end
            end
        end
        %         end
    end
end
this_k = 0;
while this_k<GA.PopulationSize
    this_min_num = min(this_violatevalue);
    k_num = find(this_violatevalue==this_min_num);
    if this_k+size(k_num)<=GA.PopulationSize
        for oo = 1:size(k_num)
            this_k = this_k + 1;
            NewX(this_k,:) = X(k_num(oo),:);
            this_violatevalue(k_num(oo)) = 99999;
            this_fitnessvalue(k_num(oo)) = -99999;
        end
    else
        now_fit = this_fitnessvalue(k_num);
        [~,n_key] = sort(now_fit,'descend');
        for oo = 1:GA.PopulationSize-this_k
            this_k = this_k + 1;
            NewX(this_k,:) = X(k_num(n_key(oo)),:);
        end
    end
end

GA.Population.X = NewX;
for kk = 1:GA.PopulationSize
    this_fitnessvalue(kk) = FitnessNum(GA.Population.X(kk,:)',Benchmark);
    this_violatevalue(kk) = ViolateNum(GA.Population.X(kk,:)',Benchmark);
end
GA.Population.FitnessValue = this_fitnessvalue(1:GA.PopulationSize);
GA.Population.ViolateValue = this_violatevalue(1:GA.PopulationSize);
end

