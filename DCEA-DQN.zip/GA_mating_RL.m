function GA = GA_mating_RL(GA,Benchmark)
% [FitSort,Fitkey] = sort(GA.Population.FitnessValue);
%clear all;
global  CurrentFE mate_state_flag Q_mating_table;
% global DQNet1 DQNet1_target;
% if isempty(DQNet1)
%     DQNet1=fitnet([32,16]);
%     Iniset=zeros(65,400);  %ǰ����Ϊ���룬���һ��ΪĿ�����
%     for i=1:40
%         k=0;
%         for j=1:55
%             if k>=10
%                 Iniset(j,i)=(unidrnd(200)-100)*0.01;
%                 k = 0;
%             else
%                 Iniset(j,i)=(unidrnd(200)-100)*0.01;
%                 k = k + 1;
%             end
%         end
%         for j=56:65
%             Iniset(j,i)=(unidrnd(200)-100)*0.01;
%         end
%     end
%     clear i j k;
%     DQNet1=train(DQNet1,Iniset(1:55,:),Iniset(56:65,:));
%     DQNet1_target=DQNet1;
% end

if isempty(CurrentFE)
    CurrentFE = 0;
end
x = GA.Population.X;
[SolutionNumber,~] = size(x);

% [min_vio,min_id] = min(GA.Population.ViolateValue);
% if length(find(GA.Population.ViolateValue==min_vio))>1
%         [GA.Population.GbestValue,BestPbestID] = max(GA.Population.FitnessValue(min_id,:));
% else
%     BestPbestID = min_id;
%     GA.Population.GbestValue = GA.Population.FitnessValue(min_id);
% end
% SaveX = GA.Population.X(BestPbestID,:);


GA.fit_best_pre = GA.Population.GbestValue;
GA.vlo_min_pre = GA.Population.Gminvlo;
this_xy = randperm(SolutionNumber);
% this_fit = NaN(2*SolutionNumber,1);
this_action = find(Q_mating_table(mate_state_flag,:)==max(Q_mating_table(mate_state_flag,:)));
this_action = this_action(1);
reward = 0;
for ii=1:2:SolutionNumber
    %     this_x = randperm(SolutionNumber,2);%�������ܻ����ظ��ĸ���
    %     this_y = randperm(SolutionNumber,2);
    
    parent_x = x(this_xy(ii),:);
    fit_parent_x = FitnessNum(parent_x',Benchmark);
    vio_parent_x =  ViolateNum(parent_x',Benchmark);
    x_key = this_xy(ii);
    parent_y = x(this_xy(ii+1),:);
    fit_parent_y = FitnessNum(parent_y',Benchmark);
    vio_parent_y =  ViolateNum(parent_y',Benchmark);
    y_key = this_xy(ii + 1);
    
    if this_action == 1 %ģ�����ʽ����
        SBX_eta =  5*(1+CurrentFE)/Benchmark.ChangeFrequency;%Խ�󣬺�����������Ƶĸ���Խ��,һ������Ϊ1
        %    SBX_eta =  1;
        SBX_r = rand;
        if SBX_r<=0.5
            SBX_gama = (2*SBX_r)^(1/(SBX_eta + 1));
        else
            SBX_gama = (1/(2*(1-SBX_r)))^(1/(SBX_eta + 1));
        end
        offspring_x1 = 0.5 * [(1 + SBX_gama) * parent_x + (1-  SBX_gama) * parent_y];
        offspring_x2 = 0.5 * [(1 -  SBX_gama) * parent_x + (1+ SBX_gama) * parent_y];
    elseif this_action == 2 %����
        this_key = randperm(GA.Dimension-1,1);
        for jj=1:GA.Dimension
            if jj<=this_key
                offspring_x1(jj)=parent_x(jj);
                offspring_x2(jj)=parent_y(jj);
            else
                offspring_x1(jj)=parent_y(jj);
                offspring_x2(jj)=parent_x(jj);
            end
        end
    else %DE
        this_key = randperm(SolutionNumber,1);
        offspring_x1 = parent_x + rand * (parent_y - x(this_key,:));
        offspring_x2 = parent_y + rand * (parent_x - x(this_key,:));
    end
    
   
    
    fit_offx1 = FitnessNum(offspring_x1',Benchmark);
    vio_offx1 = ViolateNum(offspring_x1',Benchmark);
    fit_offx2 = FitnessNum(offspring_x2',Benchmark);
    vio_offx2 = ViolateNum(offspring_x2',Benchmark);


    all_fit(ii) = fit_offx1;
    all_fit(ii+1) = fit_offx2;
    all_vlo(ii) = vio_offx1;
    all_vlo(ii + 1) = vio_offx2;
    all_x(ii,:) =offspring_x1;
    all_x(ii+1,:) =offspring_x2;
    
    if fit_offx1 > fit_parent_x && fit_offx1 > fit_parent_y 
        if vio_offx1 <= vio_parent_x && vio_offx1 <= vio_parent_x
            reward = reward + 1;
        else
            reward = reward - 1;
        end
    end
    if fit_offx2 > fit_parent_x && fit_offx2 > fit_parent_y 
        if vio_offx2 <= vio_parent_x && vio_offx2 <= vio_parent_x
            reward = reward + 1;
        else
            reward = reward - 1;
        end
    end
end

reward = reward/SolutionNumber;
Q_mating_table(mate_state_flag,this_action) = Q_mating_table(mate_state_flag,this_action) + 0.3 * (reward + 0.75 * max(Q_mating_table(mate_state_flag,:))  - Q_mating_table(mate_state_flag,this_action));

GA.Population.X = all_x;

end




