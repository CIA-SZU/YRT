function ConNum = ConFitnessNum(x,Benchmark)
ConNum = 0;
ldim = 1;
this_flag = 0;
for ii=1 : Benchmark.MPBnumber
    solution = x(Benchmark.PermutationMap(ldim:ldim+Benchmark.MPB{ii}.Dimension-1))';
    if ~isnan(solution)
        for k=1 : Benchmark.MPB{ii}.PeakNumber
            if ~sum(ismember(Benchmark.MPB{ii}.FeasiblePeak,k))
                if pdist2(solution,Benchmark.MPB{ii}.PeaksPosition(k,:),'minkowski',2)^2<=Benchmark.MPB{ii}.radius^2
                    this_flag = 1;
                    break;
                end
            end
        end
    end
    if this_flag == 1
        ConNum = 1;
    else
        ConNum = 0;
    end
    this_flag = 0;
    ldim = ldim + Benchmark.MPB{ii}.Dimension;
end
end